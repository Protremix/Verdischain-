# 🌿 Verdis — The First Fully Green Blockchain Ecosystem

<p align="center">
  <strong>Carbon-Negative Layer-1 | On-Chain Carbon Credits | Green Validator Scoring</strong><br>
  Reformation Tracking | Native AMM DEX | DPoS Consensus
</p>

<p align="center">
  <a href="https://verdischain.com">🌐 Website</a> •
  <a href="https://verdischain.com/whitepaper">📄 Whitepaper</a> •
  <a href="https://verdischain.com/dashboard">📊 Dashboard</a> •
  <a href="https://verdischain.com/executive-summary">📋 Executive Summary</a>
</p>

---

## What is Verdis?

Verdis is the world's **first fully green blockchain ecosystem** — a Layer-1 blockchain designed from the ground up to be carbon-negative. Unlike other chains that merely reduce energy consumption, Verdis makes environmental regeneration a core protocol feature.

Every layer is green:
- **Consensus** — DPoS uses 99.9% less energy than PoW, validators scored on renewable energy
- **Protocol** — Carbon credits minted on-chain, reforestation logged immutably
- **DEX** — Native AMM with eco-tokens (CARBON, ECO, GREEN, TREE, REDD)
- **Economics** — 5B VRS Carbon Offset Fund (first in blockchain history)

## Key Stats

| Metric | Value |
|--------|-------|
| Chain ID | 909 |
| Block Time | 5 seconds |
| Max Supply | 100,000,000,000 VRS |
| Circulating | 50,000,000,000 VRS |
| Validators | 27 registered, 5 active |
| DEX Pools | 6 (CARBON/VRS, ECO/VRS, CARBON/ECO, GREEN/VRS, SOLR/VRS, TST/VRS) |
| CO₂ Tracked | 1,000+ tons |
| Trees Logged | 15,000 |
| Green Validators | 6 |
| Block Reward | 16 VRS |

## Features

### Core Blockchain
- **DPoS Consensus** — Round-robin block production every 5 seconds
- **secp256k1 Cryptography** — ECDSA signatures with public key recovery
- **Keccak256 Addresses** — Ethereum-compatible (0x...) address format
- **SHA-256 Block Hashing** — Tamper-proof chain with Merkle tree verification
- **State Persistence** — Full chain state saved to disk, survives restarts

### Eco Features (First in Blockchain)
- **Carbon Credit System** — Mint, trade, and retire carbon credits on-chain
- **Reforestation Tracking** — Immutable tree planting records with verification
- **Green Validator Scoring** — Validators rated by renewable energy use
- **Carbon Offset Fund** — 5B VRS dedicated to environmental projects
- **Eco-Tokens** — CARBON, ECO, GREEN, TREE, REDD tradeable on the DEX

### Native DEX
- **AMM Protocol** — Constant product formula (x * y = k) built into the chain
- **6 Liquidity Pools** — Including eco-token trading pairs
- **0.3% Fee** — Distributed to liquidity providers
- **LP Tokens** — Represent pool share

### Smart Contracts
- **Stack-based VM** — Bytecode execution engine
- **6 Deployed Contracts** — Including EcoDepositCalculator, EcoStakingReward
- **Token Standards** — ERC-20, ERC-721, ERC-1155 support

### Wallet & Access
- **Native Wallet** — Built into the dashboard, no MetaMask required
- **Ethereum JSON-RPC** — 25+ methods, Chain ID 909
- **MetaMask/Trust Wallet** — Optional integration via EIP-1193

### Security
- secp256k1 signatures with recovery
- Nonce-based replay protection (Chain ID embedded)
- Rate limiting: 30/min general, 5/min transactions
- Admin API key authentication
- Validator slashing (double-sign, downtime, invalid blocks)
- Input validation on all endpoints
- Mempool limits (1000 max), max TX 1B VRS, max 500 txs/block

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Language | TypeScript (Node.js 20) |
| Cryptography | @noble/secp256k1, @noble/hashes |
| Framework | Express.js |
| RPC | Ethereum JSON-RPC (Chain ID 909) |
| Frontend | Vanilla HTML/CSS/JS, Chart.js |
| Deployment | Nginx, systemd, Let's Encrypt SSL |

## Project Structure

```
verdis/
├── src/
│   ├── core/
│   │   ├── consensus.ts    # DPoS blockchain core
│   │   ├── block.ts        # Block structure & validation
│   │   ├── transaction.ts  # Transaction creation & signing
│   │   ├── dex.ts          # AMM DEX engine
│   │   ├── eco.ts          # Carbon credits, reforestation, green scoring
│   │   ├── vm.ts           # Stack-based smart contract VM
│   │   ├── market.ts       # Market data tracking
│   │   ├── security.ts     # Security checks & rate limiting
│   │   ├── persistence.ts  # State save/load
│   │   ├── fees.ts         # Fee calculation
│   │   └── parallel-executor.ts
│   ├── api/
│   │   ├── server.ts       # REST API (50+ endpoints) & web server
│   │   └── jsonrpc.ts      # Ethereum JSON-RPC server
│   ├── wallet/
│   │   └── wallet.ts       # Key management, wallet operations
│   ├── crypto.ts           # secp256k1 + Keccak256 + SHA-256
│   ├── types.ts            # Type definitions
│   └── index.ts            # Entry point
├── web/                    # Dashboard, landing, whitepaper
├── package.json
└── tsconfig.json
```

## Quick Start

### Prerequisites
- Node.js 20+
- npm

### Install & Run

```bash
# Clone
git clone https://github.com/verdischain/verdis.git
cd verdis

# Install dependencies
npm install

# Build
npm run build

# Start the node
npm start
```

The blockchain will be running at `http://localhost:3200`.

### Add to MetaMask / Trust Wallet

| Parameter | Value |
|-----------|-------|
| Network Name | Verdis |
| Chain ID | 909 |
| Symbol | VRS |
| RPC URL | https://rpc.verdischain.com |
| Explorer | https://verdischain.com |

## API Overview

### REST API (50+ endpoints)

```
GET  /api/blockchain/info          # Chain info
GET  /api/blockchain/blocks        # Block list
GET  /api/blockchain/block/:height # Block by height
GET  /api/validators               # Validator list
GET  /api/dex/pools                # DEX pools
GET  /api/eco/impact               # Eco impact stats
GET  /api/token/info               # Token info
GET  /api/network/info             # Network config
POST /api/wallet/create            # Create wallet
POST /api/wallet/balance           # Check balance
POST /api/transfer                 # Send VRS
POST /api/dex/swap                 # Swap tokens
POST /api/dex/add-liquidity        # Add liquidity
POST /api/eco/carbon/mint          # Mint carbon credits
POST /api/eco/reforest/log         # Log reforestation
GET  /api/sale/info                # Token sale info
POST /api/sale/buy                 # Buy VRS
```

### JSON-RPC (25+ methods)

```bash
# Get chain ID
curl -X POST https://rpc.verdischain.com/rpc \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}'

# Get latest block
curl -X POST https://rpc.verdischain.com/rpc \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}'
```

## Tokenomics

| Allocation | % | Tokens | Status |
|-----------|---|--------|--------|
| Token Sale (IDO) | 40% | 40B VRS | Live (Presale) |
| Ecosystem & Validators | 20% | 20B VRS | Active |
| Community Rewards | 15% | 15B VRS | Active |
| DEX Liquidity | 10% | 10B VRS | Active |
| Team (2yr lock) | 10% | 10B VRS | Locked |
| **Carbon Offset Fund** | **5%** | **5B VRS** | **Active** |

**Sale Price:** $0.001 per VRS | Accepts ETH, BNB, USDT, USDC

## Roadmap

### Phase 1 — Completed (Q3 2026)
- ✅ Core blockchain with DPoS consensus
- ✅ Native wallet (no MetaMask required)
- ✅ AMM DEX with 6 liquidity pools
- ✅ Carbon credit minting and tracking
- ✅ Reforestation logging (15,000 trees)
- ✅ Green validator scoring (first in blockchain)
- ✅ Smart contract VM
- ✅ Ethereum JSON-RPC compatibility
- ✅ Token Sale (IDO) — live
- ✅ Production deployment at verdischain.com

### Phase 2 — In Progress (Q4 2026)
- 🔄 Cross-chain bridge (BSC / Ethereum)
- 🔄 CoinGecko and CoinMarketCap listing
- 🔄 Mobile wallet app
- 🔄 Carbon credit marketplace
- 🔄 Reforestation partnerships

### Phase 3 — Planned (2027)
- 📋 EVM/Solidity smart contracts
- 📋 Cross-chain atomic swaps
- 📋 Enterprise carbon tracking API
- 📋 ZK-rollup scaling

## Links

- 🌐 [Website](https://verdischain.com)
- 📊 [Dashboard](https://verdischain.com/dashboard)
- 📄 [Whitepaper](https://verdischain.com/whitepaper)
- 📋 [Executive Summary](https://verdischain.com/executive-summary)
- 📄 [PDF Whitepaper](https://verdischain.com/whitepaper.pdf)
- 🛒 [Buy VRS](https://verdischain.com/dashboard#sale)
- 📡 RPC: `https://rpc.verdischain.com`
- 🔗 Chain ID: 909

## License

MIT License — see [LICENSE](LICENSE) file for details.

## Disclaimer

This whitepaper and repository are for informational purposes only and do not constitute financial advice. Cryptocurrency investments carry risk. The Verdis team is not liable for any financial decisions made based on this material.

---

<p align="center">
  <strong>Verdis — The First Fully Green Blockchain Ecosystem</strong><br>
  <em>The chain doesn't just consume less. It actively heals the planet.</em>
</p>
